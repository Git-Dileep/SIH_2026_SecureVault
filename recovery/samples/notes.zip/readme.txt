Investigator notes for SIH 2026.
Do not modify the evidence image.
